﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Viewport3DX.cs" company="Helix 3D Toolkit">
//   http://helixtoolkit.codeplex.com, license: MIT
// </copyright>
// <summary>
//   Provides a Viewport control.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System.Collections;
using System.IO;
using System.Windows.Forms.VisualStyles;
using System.Windows.Media.Imaging;
using HelixToolkit.Wpf.SharpDX.Core;
using HelixToolkit.Wpf.SharpDX.Helpers;
using HelixToolkit.Wpf.SharpDX.Model.Shader;
using HelixToolkit.Wpf.SharpDX.Render;
using SharpDX;
using SharpDX.Direct2D1;
using Bitmap = System.Drawing.Bitmap;

namespace HelixToolkit.Wpf.SharpDX
{
	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.Diagnostics;
	using System.Linq;
	using System.Windows;
	using System.Windows.Controls;
	using System.Windows.Documents;
	using System.Windows.Input;
	using System.Windows.Markup;
	using System.Windows.Media;
	using System.Windows.Media.Animation;
	using System.Windows.Media.Media3D;
	using HelixToolkit.Wpf;
	using System.Collections.Specialized;
	using HelixToolkit.Wpf.SharpDX.Controllers;

	/// <summary>
	/// Provides a Viewport control.
	/// </summary>
	[DefaultEvent("OnChildrenChanged")]
	[DefaultProperty("Children")]
	[ContentProperty("Items")]
	//[TemplatePart(Name = "PART_CameraController", Type = typeof(CameraController))]
	[TemplatePart(Name = "PART_Canvas", Type = typeof(DPFCanvas))]
	//[TemplatePart(Name = "PART_AdornerLayer", Type = typeof(AdornerDecorator))]
	//[TemplatePart(Name = "PART_CoordinateView", Type = typeof(Viewport3D))]
	//[TemplatePart(Name = "PART_ViewCubeViewport", Type = typeof(Viewport3D))]
	//[Localizability(LocalizationCategory.NeverLocalize)]
	public partial class Viewport3DX : IRenderer//ItemsControl
    {

		/// <summary>
		/// The stop watch
		/// </summary>
		public static readonly Stopwatch StopWatch = new Stopwatch();

		/// <summary>
		///   The camera history stack.
		/// </summary>
		/// <remarks>
		///   Implemented as a list since we want to remove items at the bottom of the stack.
		/// </remarks>
		private readonly List<CameraSetting> cameraHistory = new List<CameraSetting>();

		/// <summary>
		/// The frame rate stopwatch.
		/// </summary>
		private readonly Stopwatch fpsWatch = new Stopwatch();
        
		/// <summary>
		/// The camera controller.
		/// </summary>
		//private readonly CameraViewController cameraController;
        /*
		private InputController inputController;
		public InputController InputController
		{
			get
			{
				if (inputController == null)
					inputController = new InputController(this);
				return inputController;
			}
		}*/

		/// <summary>
		/// The frame counter.
		/// </summary>
		private int frameCounter;

		/// <summary>
		/// The "control has been loaded before" flag.
		/// </summary>
		private bool hasBeenLoadedBefore;

		/// <summary>
		///   The is spinning flag.
		/// </summary>
		//private bool isSpinning;

		/// <summary>
		///   The move speed.
		/// </summary>
		private Vector3D moveSpeed;

		/// <summary>
		///   The pan speed.
		/// </summary>
		private Vector3D panSpeed;
        
		/// <summary>
		///   The rotation speed.
		/// </summary>
		private Vector rotationSpeed;

		/// <summary>
		/// Initializes static members of the <see cref="Viewport3DX" /> class.
		/// </summary>
		/// 
		private MeshGeometryRenderData backGroundRenderData;

		/// <summary>
		/// Turn on/off viewport gradient background
		/// true - by default
		/// </summary>
		public bool IsBackgroundEnabled { get; set; }

//		public void RenderControlCrteated()
//		{
//			CameraController.UpdateCursor();
//		}

		static Viewport3DX()
		{
			DefaultStyleKeyProperty.OverrideMetadata(
				typeof(Viewport3DX), new FrameworkPropertyMetadata(typeof(Viewport3DX)));
		}

        public List<object> Items { get; private set; }

        public Viewport3DX(IDPFCanvas canvas, Camera camera) :this() {//
            Items = new List<object>(); 
            this.RenderHost = canvas;
            Camera = camera;
	       // this.cameraController = cameraController;
            this.RenderHost.Renderable = this;
            this.OnCameraChanged();

//            RenderHost.InputController = new InputController(this);
//            RenderHost.InputController.Initialize(control);
        }

	    /// <summary>
        /// Initializes a new instance of the <see cref="Viewport3DX" /> class.
        /// </summary>
        public Viewport3DX()
		{
			IsBackgroundEnabled = true;
		
			FpsCounter = new FpsCounter();

			//this.Camera = this.Orthographic ? (ProjectionCamera)this.orthographicCamera : this.perspectiveCamera;

			//this.cameraController = new CameraViewController(Camera, RenderHost);

			this.fpsWatch.Start();

			this.Loaded += this.ControlLoaded;
			this.Unloaded += this.ControlUnloaded;

			Planes = new List<CuttingPlane>();
			BlockBoundingBoxes = new List<BoundingBoxColoring>();
			IsToothValidationRenderingEnabled = true;
			Background = new LinearGradientBrush(Colors.Transparent, Colors.Transparent,0);
			//SphereColoring = new BoundingSphereColoring(new Vector3(0),20,5,Colors.Red.ToColor());
			//CaptureMouseWheelWhenUnfocusedBehavior.SetIsEnabled(this, true);
		}

		public IDPFCanvas RenderHost { get; set; }
        

		/// <summary>
		/// Adds the specified move force.
		/// </summary>
		/// <param name="dx">
		/// The delta x. 
		/// </param>
		/// <param name="dy">
		/// The delta y. 
		/// </param>
		/// <param name="dz">
		/// The delta z. 
		/// </param>
		public void AddMoveForce(double dx, double dy, double dz)
		{
			this.AddMoveForce(new Vector3D(dx, dy, dz));
		}

		Stopwatch renderTimer;
		protected override void OnRender(DrawingContext drawingContext)
		{
			base.OnRender(drawingContext);
			if (renderTimer == null)
				renderTimer = Stopwatch.StartNew();
			FpsCounter.AddFrame(renderTimer.Elapsed, 1);
		}

		/// <summary>
		/// Adds the specified move force.
		/// </summary>
		/// <param name="delta">
		/// The delta. 
		/// </param>
		public void AddMoveForce(Vector3D delta)
		{
			this.PushCameraSetting();
			this.moveSpeed += delta * 40;
		}

		/// <summary>
		/// Adds the specified pan force.
		/// </summary>
		/// <param name="dx">
		/// The delta x. 
		/// </param>
		/// <param name="dy">
		/// The delta y. 
		/// </param>
		public void AddPanForce(double dx, double dy)
		{
			var pcam = this.Camera as ProjectionCamera;
			this.AddPanForce(pcam.FindPanVector(dx, dy));
		}

		/// <summary>
		/// The add pan force.
		/// </summary>
		/// <param name="pan">
		/// The pan. 
		/// </param>
		public void AddPanForce(Vector3D pan)
		{
			if (!this.IsPanEnabled)
			{
				return;
			}

			this.PushCameraSetting();
			this.panSpeed += pan * 40;
		}

		public void AddSimplePanForce(double dx, double dy)
		{
			var pcam = this.Camera as ProjectionCamera;

			//CameraController.Pan((int)dx, (int)dy);
			//panHandler.Pan(pcam.FindPanVector(dx, dy));
			//            this.AddPanForce(pcam.FindPanVector(dx, dy));
		}

		/// <summary>
		/// The add rotate force.
		/// </summary>
		/// <param name="dx">
		/// The delta x. 
		/// </param>
		/// <param name="dy">
		/// The delta y. 
		/// </param>
		public void AddRotateForce(double dx, double dy)
		{
			var pcam = this.Camera as ProjectionCamera;

			if (!this.IsRotationEnabled || pcam == null)
			{
				return;
			}

			this.PushCameraSetting();
			var rotationPoint3D = pcam.Target;
			var rotationPosition = new Point(this.ActualWidth / 2, this.ActualHeight / 2);
			this.rotationSpeed.X += dx * 40;
			this.rotationSpeed.Y += dy * 40;
		}

		/// <summary>
		/// Adds the zoom force.
		/// </summary>
		/// <param name="dx">
		/// The delta. 
		/// </param>
		public void AddZoomForce(double dx)
		{
			var pcam = this.Camera as ProjectionCamera;
			if (!this.IsZoomEnabled || pcam == null)
			{
				return;
			}

			this.AddZoomForce(dx, pcam.Target);
		}

		/// <summary>
		/// Adds the zoom force.
		/// </summary>
		/// <param name="dx">
		/// The delta. 
		/// </param>
		/// <param name="zoomOrigin">
		/// The zoom origin. 
		/// </param>
		public void AddZoomForce(double dx, Point3D zoomOrigin)
		{
			if (!this.IsZoomEnabled)
			{
				return;
			}

			this.PushCameraSetting();
			var zoomPoint3D = zoomOrigin;
            var zoomSpeed = dx * 8;
		}

		/// <summary>
		/// Changes the direction of the camera.
		/// </summary>
		/// <param name="lookDir">
		/// The look direction. 
		/// </param>
		/// <param name="upDir">
		/// The up direction. 
		/// </param>
		/// <param name="animationTime">
		/// The animation time. 
		/// </param>
		public void ChangeDirection(Vector3D lookDir, Vector3D upDir, double animationTime = 500)
		{
			this.StopAnimations();
			this.PushCameraSetting();
			var pcam = this.Camera as ProjectionCamera;
			if (pcam != null)
			{
				pcam.ChangeDirection(lookDir, upDir, animationTime);
			}
		}

		/// <summary>
		/// Finds the nearest 3D point in the scene.
		/// </summary>
		/// <param name="pt">
		/// The screen point (2D).
		/// </param>
		/// <returns>
		/// A Point3D or null.
		/// </returns>
		public Point3D? FindNearestPoint(Point pt)
		{
			return ViewportExtensions.FindNearestPoint(this, pt);
		}

		/// <summary>
		/// Change the camera to look at the specified point.
		/// </summary>
		/// <param name="p">
		/// The point.
		/// </param>
		public void LookAt(Point3D p)
		{
			this.LookAt(p, 0);
		}

		/// <summary>
		/// Change the camera to look at the specified point.
		/// </summary>
		/// <param name="p">
		/// The point.
		/// </param>
		/// <param name="animationTime">
		/// The animation time.
		/// </param>
		public void LookAt(Point3D p, double animationTime)
		{
			var projectionCamera = this.Camera as ProjectionCamera;
			if (projectionCamera == null)
			{
				return;
			}

			projectionCamera.LookAt(p, animationTime);
		}

		/// <summary>
		/// Change the camera to look at the specified point.
		/// </summary>
		/// <param name="p">
		/// The point.
		/// </param>
		/// <param name="distance">
		/// The distance.
		/// </param>
		/// <param name="animationTime">
		/// The animation time.
		/// </param>
		public void LookAt(Point3D p, double distance, double animationTime)
		{
			var projectionCamera = this.Camera as ProjectionCamera;
			if (projectionCamera == null)
			{
				return;
			}

			projectionCamera.LookAt(p, distance, animationTime);
		}

		/// <summary>
		/// Change the camera to look at the specified point.
		/// </summary>
		/// <param name="p">
		/// The point.
		/// </param>
		/// <param name="direction">
		/// The direction.
		/// </param>
		/// <param name="animationTime">
		/// The animation time.
		/// </param>
		public void LookAt(Point3D p, Vector3D direction, double animationTime)
		{
			var projectionCamera = this.Camera as ProjectionCamera;
			if (projectionCamera == null)
			{
				return;
			}

			projectionCamera.LookAt(p, direction, animationTime);
		}

		/// <summary>
		/// When overridden in a derived class, is invoked whenever application code or internal processes call <see cref="M:System.Windows.FrameworkElement.ApplyTemplate" />.
		/// </summary>
		/// <exception cref="HelixToolkitException">{0} is missing from the template.</exception>
		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();
			this.RenderHost = this.GetTemplateChild("PART_Canvas") as DPFCanvas;
			if (this.RenderHost != null)
			{
				this.RenderHost.Renderable = this;
			}

			// update the coordinateview camera
			this.OnCameraChanged();
		}

		/// <summary>
		/// Pushes the camera setting.
		/// </summary>
		public void PushCameraSetting()
		{
			this.cameraHistory.Add(new CameraSetting(this.Camera as ProjectionCamera));
			if (this.cameraHistory.Count > 100)
			{
				this.cameraHistory.RemoveAt(0);
			}
		}

		public bool RestoreCameraSetting()
		{
			if (this.cameraHistory.Count > 0)
			{
				var cs = this.cameraHistory[this.cameraHistory.Count - 1];
				this.cameraHistory.RemoveAt(this.cameraHistory.Count - 1);
				cs.UpdateCamera((ProjectionCamera)this.Camera);
				return true;
			}

			return false;
		}

		/// <summary>
		/// Detaches the current scene and attaches it again. 
		/// Call it if you want to repeat the entire Attach-Pass
		/// </summary>
		public void ReAttach()
		{
			if (this.RenderHost != null)
			{
				this.RenderHost.Renderable = null;
				this.RenderHost.Renderable = this;
			}
		}

		/// <summary>
		/// Detaches the current scene.         
		/// Call it if you want to detouch the scene from the renderer.
		/// Call <see cref="ReAttach"/> in order to attach the current scene again.
		/// </summary>
		public void Detach()
		{
			if (this.RenderHost != null)
			{
				this.RenderHost.Renderable = null;
			}
		}

		/// <summary>
		/// Resets the view.
		/// </summary>
		public void Reset()
		{
			if (!this.IsZoomEnabled || !this.IsRotationEnabled || !this.IsPanEnabled)
			{
				return;
			}

			this.PushCameraSetting();
			if (this.DefaultCamera != null)
			{
				this.DefaultCamera.CopyTo(this.Camera as ProjectionCamera);
			}
			else
			{
				this.Camera.Reset();
				this.ZoomExtents();
			}
		}

		/// <summary>
		/// Change the camera position and directions.
		/// </summary>
		/// <param name="newPosition">
		/// The new camera position.
		/// </param>
		/// <param name="newDirection">
		/// The new camera look direction.
		/// </param>
		/// <param name="newUpDirection">
		/// The new camera up direction.
		/// </param>
		/// <param name="animationTime">
		/// The animation time.
		/// </param>
		public void SetView(Point3D newPosition, Vector3D newDirection, Vector3D newUpDirection, double animationTime)
		{
			var projectionCamera = this.Camera as ProjectionCamera;
			if (projectionCamera == null)
			{
				return;
			}

			projectionCamera.AnimateTo(newPosition, newDirection, newUpDirection, animationTime);
		}

		/// <summary>
		/// Starts spinning.
		/// </summary>
		/// <param name="speed">The speed.</param>
		/// <param name="position">The position.</param>
		/// <param name="aroundPoint">The point to spin around.</param>
		public void StartSpin(Vector speed, Point position, Point3D aroundPoint)
		{
			var spinningSpeed = speed;
			var spinningPosition = position;
            var spinningPoint3D = aroundPoint;
			//this.isSpinning = true;
		}

		/// <summary>
		///   Stops the spinning.
		/// </summary>
		public void StopSpin()
		{
			//this.isSpinning = false;
		}

		/// <summary>
		/// Zooms to the extents of the specified bounding box.
		/// </summary>
		/// <param name="bounds">
		/// The bounding box.
		/// </param>
		/// <param name="animationTime">
		/// The animation time.
		/// </param>
		public void ZoomExtents(Rect3D bounds, double animationTime = 0)
		{
			ViewportExtensions.ZoomExtents(this, bounds, animationTime);
		}

		/// <summary>
		/// Zooms to the extents of the model.
		/// </summary>
		/// <param name="animationTime">
		/// The animation time (milliseconds). 
		/// </param>
		public void ZoomExtents(double animationTime = 200)
		{
			if (!this.IsZoomEnabled)
			{
				return;
			}

			this.PushCameraSetting();
			ViewportExtensions.ZoomExtents(this, animationTime);
		}

		/// <summary>
		/// Attaches the elements to the specified host.
		/// </summary>
		/// <param name="host">The host.</param>
		void IRenderer.Attach(IRenderHost host)
		{
			foreach (IRenderable e in this.Items)
			{
				e.Attach(host);
			}

			StopWatch.Start();
		}

		/// <summary>
		/// Detaches the elements.
		/// </summary>
		void IRenderer.Detach()
		{
			foreach (IRenderable e in this.Items)
			{
				e.Detach();
			}
		}

		CuttingPlane[] planes;
		RenderData[] renderDatas;
		/// <summary>
		/// Renders the scene.
		/// </summary>
		void IRenderer.Render(RenderContext context)
		{
			if (renderDatas == null)
				return;

			context.RenderCamera();

			context.IlluminationSettings = IlluminationSettings;

			if (IsBackgroundEnabled)
			{
				backGroundRenderData.Render(context);
			}

			context.SetPlanes(planes);
			if (IsToothValidationRenderingEnabled)
			{
				context.SetBoxes(boxesColorings);
			}

//			if(SphereColoring != null) {
//				context.SetSphere(SphereColoring);
//			}

			var techicues = new List<KeyValuePair<RenderData, SharpDX.RenderTechnique>>();
			try
			{
				if (context.IsMakingPhoto)
					CheckTechniques(renderDatas, techicues);

				foreach (var e in renderDatas)
				{
					if (e != backGroundRenderData)
					{

					}
					e.Render(context);
				}
			}
			finally
			{
				foreach (var item in techicues)
					item.Key.RenderTechniqueUserDefinded = item.Value;
			}
		}

		static RenderTechnique[] photoTechniques = new[]
		{
			Techniques.RenderWires,
			Techniques.RenderVertex,
		};

		private void CheckTechniques(RenderData[] renderDatas, List<KeyValuePair<RenderData, RenderTechnique>> techicues)
		{

			for (int i = 0; i < renderDatas.Length; i++)
			{
				var rd = renderDatas[i];

				var itemsRd = rd as ItemsRenderData;
				if (itemsRd != null)
				{
					CheckTechniques(itemsRd.Items, techicues);
					continue;
				}

				if (!photoTechniques.Contains(rd.RenderTechniqueUserDefinded))
					continue;
				techicues.Add(new KeyValuePair<RenderData, RenderTechnique>(rd, rd.RenderTechniqueUserDefinded));
				rd.RenderTechniqueUserDefinded = Techniques.RenderPhong;
			}
		}

		//DateTime prevFPSTime = DateTime.Now;
		/// <summary>
		/// Updates the scene.
		/// </summary>
		/// <param name="renderContext"></param>
		/// <param name="timeSpan">The time span.</param>
		void IRenderer.Update(RenderContext renderContext, TimeSpan timeSpan)
		{
			this.FpsCounter.AddFrame(timeSpan);
			if (backGroundRenderData == null)
			{
				//TopLeftColor = Colors.White;
				//TopRightColor = Colors.White;
				//BottomLeftColor = Colors.Black;
				//BottomRightColor = Colors.Black;
				UpdateBackgroundColor();
			}

			renderContext.GlobalRenderTechniques = GlobalRenderTechniques;

			CopyCamera(renderContext);

			planes = Planes.ToArray();
			boxesColorings = BlockBoundingBoxes.ToArray();
			var _renderDatas = new List<RenderData>(Items.Count);

			foreach (var e in Items.Cast<Element3D>())
			{
				e.Update(renderContext, timeSpan);
				if (e.RenderData != null)
					_renderDatas.Add(e.RenderData);
			}
			renderDatas = _renderDatas.ToArray();
		}

		public static BitmapSource GenerateBackGroundBitmapSource(Brush brush, int height, int width)
		{

			var bmp = new RenderTargetBitmap(width, (int)(height), 96, 96, PixelFormats.Pbgra32);
			var drawingVisual = new DrawingVisual();
			using (var ctx = drawingVisual.RenderOpen())
			{
				ctx.DrawRectangle(brush, null, new Rect(0, 0, bmp.PixelWidth, bmp.PixelHeight));
			}
			bmp.Render(drawingVisual);

			return bmp;
		}
		public void UpdateBackgroundColor()
		{
			if (backGroundRenderData == null)
			{
				backGroundRenderData = new MeshGeometryRenderData(this.RenderHost, Techniques.RenderBackground);
				var mesh = new MeshGeometry3D();


				var bitmap = GenerateBackGroundBitmapSource(Background, 100, 100);
				mesh.Positions = new Vector3Collection(){
					new Vector3(-1,-1,1),
					new Vector3(1,-1,1),
				    new Vector3(-1, 1, 1),
				    new Vector3(1, 1, 1)
				};

				mesh.Indices = new IntCollection() { 0, 1, 2, 1, 3, 2 };
                mesh.TextureCoordinates = new Vector2Collection() { new Vector2(0, 1), new Vector2(1, 1), new Vector2(0, 0), new Vector2(1, 0) };
				backGroundRenderData.RenderSources.Positions.Update(mesh);
				backGroundRenderData.RenderSources.Indices.Update(mesh);
				//backGroundRenderData.RenderSources.Colors.Update(mesh);
				backGroundRenderData.RenderSources.TextureCoordinates.Update(mesh);
				backGroundRenderData.RenderTechniqueUserDefinded = Techniques.RenderBackground;
				backGroundRenderData.Material = new PhongMaterial() { DiffuseMap = bitmap };
				backGroundRenderData.Visible = true;
				backGroundRenderData.TextureCoordScale = new Vector2(1);

				backGroundRenderData.Transform = global::SharpDX.Matrix.Identity;
				backGroundRenderData.Attach();
			}
			else
			{
				var bitmap = GenerateBackGroundBitmapSource(Background, 100, 100);
				backGroundRenderData.Material = new PhongMaterial() { DiffuseMap = bitmap };
			}
		}

		/// <summary>
		/// Called when the camera is changed.
		/// </summary>
		protected virtual void OnCameraChanged()
		{
			var projectionCamera = this.Camera as ProjectionCamera;
			if (projectionCamera == null)
			{
				return;
			}

			if (this.ShowFieldOfView)
			{
				this.UpdateFieldOfViewInfo();
			}

			if (this.ShowCameraInfo)
			{
				this.UpdateCameraInfo();
			}
		}

		/// <summary>
		/// Invoked when an unhandled MouseUp attached event reaches an element in its route that is derived from this class. Implement this method to add class handling for this event.
		/// </summary>
		/// <param name="e"></param>
		protected override void OnMouseUp(MouseButtonEventArgs e)
		{
			base.OnMouseUp(e);
			this.MouseUpHitTest(e);
		}

		public void EmulateMouseUpByTouch(MouseButtonEventArgs e)
		{
			this.MouseUpHitTest(e);
		}

	

		public void EmulateMouseDownByTouch(MouseButtonEventArgs e)
		{
			//this.Focus();
			//this.MouseDownHitTest(e);
		}

		/// <summary>
		/// Invoked when an unhandled MouseMove attached event reaches an element in its route that is derived from this class.
		/// </summary>
		/// <param name="e">
		/// The <see cref="T:System.Windows.Input.MouseEventArgs"/> that contains the event data.
		/// </param>
		protected override void OnMouseMove(MouseEventArgs e)
		{
			base.OnMouseMove(e);
			this.MouseMoveHitTest(e);
			if (this.EnableCurrentPosition)
			{
				var pt = e.GetPosition(this);
				var pos = this.FindNearestPoint(pt);
				if (pos != null)
				{
					this.CurrentPosition = pos.Value;
				}
				else
				{
					var p = this.UnProjectOnPlane(pt);
					if (p != null)
					{
						this.CurrentPosition = p.Value;
					}
				}
			}
		}

		public void EmulateMouseMoveByTouch(Point pt)
		{
			this.MouseMoveHitTest(pt);
			if (this.EnableCurrentPosition)
			{
				var pos = this.FindNearestPoint(pt);
				if (pos != null)
				{
					this.CurrentPosition = pos.Value;
				}
				else
				{
					var p = this.UnProjectOnPlane(pt);
					if (p != null)
					{
						this.CurrentPosition = p.Value;
					}
				}
			}
		}

		/// <summary>
		/// call OnRendering for RenderHost
		/// </summary>
		public void ForceRender()
		{
			base.InvalidateVisual();
		}

		/// <summary>
		/// Invoked when an unhandled MouseWheel attached event reaches an element in its route that is derived from this class. Implement this method to add class handling for this event.
		/// </summary>
		/// <param name="e">The <see cref="T:System.Windows.Input.MouseWheelEventArgs" /> that contains the event data.</param>
		protected override void OnMouseWheel(MouseWheelEventArgs e)
		{
			base.OnMouseWheel(e);
			if (!this.IsZoomEnabled)
			{
				return;
			}

			if (this.ZoomAroundMouseDownPoint)
			{
				Point point = e.GetPosition(this);
				Point3D nearestPoint;
				Vector3D normal;
				Model3D visual;
				if (this.FindNearest(point, out nearestPoint, out normal, out visual))
				{
					this.AddZoomForce(-e.Delta * 0.001, nearestPoint);
					e.Handled = true;
					return;
				}
			}

			this.AddZoomForce(-e.Delta * 0.001);
			e.Handled = true;
		}

		/// <summary>
		/// Raises the camera changed event.
		/// </summary>
		protected virtual void RaiseCameraChangedEvent()
		{
			// e.Handled = true;
			var args = new RoutedEventArgs(CameraChangedEvent);
			this.RaiseEvent(args);
		}

		/// <summary>
		/// Animates the opacity of the specified object.
		/// </summary>
		/// <param name="obj">
		/// The object to animate.
		/// </param>
		/// <param name="toOpacity">
		/// The to opacity.
		/// </param>
		/// <param name="animationTime">
		/// The animation time.
		/// </param>
		private static void AnimateOpacity(UIElement obj, double toOpacity, double animationTime)
		{
			var a = new DoubleAnimation(toOpacity, new Duration(TimeSpan.FromMilliseconds(animationTime)))
			{
				AccelerationRatio = 0.3,
				DecelerationRatio = 0.5
			};
			obj.BeginAnimation(OpacityProperty, a);
		}

		/// <summary>
		/// The back view event handler.
		/// </summary>
		/// <param name="sender">
		/// The sender. 
		/// </param>
		/// <param name="e">
		/// The event arguments. 
		/// </param>
		private void BackViewHandler(object sender, ExecutedRoutedEventArgs e)
		{
			if (this.IsModelUpDirectionY())
			{
				this.ChangeDirection(new Vector3D(0, 0, 1), new Vector3D(0, 1, 0));
			}
			else
			{
				this.ChangeDirection(new Vector3D(1, 0, 0), new Vector3D(0, 0, 1));
			}
		}

		/// <summary>
		/// The bottom view event handler.
		/// </summary>
		/// <param name="sender">
		/// The sender. 
		/// </param>
		/// <param name="e">
		/// The event arguments. 
		/// </param>
		private void BottomViewHandler(object sender, ExecutedRoutedEventArgs e)
		{
			if (this.IsModelUpDirectionY())
			{
				this.ChangeDirection(new Vector3D(0, 1, 0), new Vector3D(0, 0, 1));
			}
			else
			{
				this.ChangeDirection(new Vector3D(0, 0, 1), new Vector3D(0, -1, 0));
			}
		}

		/// <summary>
		/// Determines whether the model up direction is (0,1,0).
		/// </summary>
		/// <returns>
		///   <c>true</c> if the up direction is (0,1,0); otherwise, <c>false</c>.
		/// </returns>
		public bool IsModelUpDirectionY()
		{
			return this.ModelUpDirection.Y.Equals(1);
		}

		public void ClearBoxes()
		{
			BlockBoundingBoxes.Clear();
		}

		public void AddBlockBox(BoundingBoxColoring box)
		{
			BlockBoundingBoxes.Add(box);
		}

		public bool IsToothValidationRenderingEnabled { get; set; }

		/// <summary>
		/// Handles the change of the render technique        
		/// </summary>
		private void RenderTechniquePropertyChanged()
		{
			if (this.RenderHost != null)
			{
				// remove the scene
				this.RenderHost.Renderable = null;

				// if new rendertechnique set, attach the scene
				if (this.RenderTechnique != null)
				{
					this.RenderHost.Renderable = this;
				}
			}
		}

		/// <summary>
		/// Handles changes in the camera properties.
		/// </summary>
		private void CameraPropertyChanged()
		{
			// Raise notification
			this.RaiseCameraChangedEvent();

			// Update the CoordinateView camera direction
			this.OnCameraChanged();
		}

		/// <summary>
		/// Clamps the specified value between the limits.
		/// </summary>
		/// <param name="value">
		/// The value. 
		/// </param>
		/// <param name="min">
		/// The min. 
		/// </param>
		/// <param name="max">
		/// The max. 
		/// </param>
		/// <returns>
		/// The clamp. 
		/// </returns>
		private double Clamp(double value, double min, double max)
		{
			if (value < min)
			{
				return min;
			}

			if (value > max)
			{
				return max;
			}

			return value;
		}

		/// <summary>
		/// Called when the control is loaded.
		/// </summary>
		/// <param name="sender">
		/// The sender.
		/// </param>
		/// <param name="e">
		/// The event arguments.
		/// </param>
		private void ControlLoaded(object sender, RoutedEventArgs e)
		{
//			if (!this.hasBeenLoadedBefore)
//			{
//				if (this.DefaultCamera != null)
//				{
//					this.DefaultCamera.CopyTo(this.perspectiveCamera);
//					this.DefaultCamera.CopyTo(this.orthographicCamera);
//				}
//
//				this.hasBeenLoadedBefore = true;
//			}

			if (this.ZoomExtentsWhenLoaded)
			{
				this.ZoomExtents();
			}
		}

		/// <summary>
		/// Called when the control is unloaded.
		/// </summary>
		/// <param name="sender">
		/// The sender.
		/// </param>
		/// <param name="e">
		/// The event arguments.
		/// </param>
		private void ControlUnloaded(object sender, RoutedEventArgs e)
		{
		}

		/// <summary>
		/// The front view event handler.
		/// </summary>
		/// <param name="sender">
		/// The sender. 
		/// </param>
		/// <param name="e">
		/// The event arguments. 
		/// </param>
		private void FrontViewHandler(object sender, ExecutedRoutedEventArgs e)
		{
			if (this.IsModelUpDirectionY())
			{
				this.ChangeDirection(new Vector3D(0, 0, -1), new Vector3D(0, 1, 0));
			}
			else
			{
				this.ChangeDirection(new Vector3D(-1, 0, 0), new Vector3D(0, 0, 1));
			}
		}

		/// <summary>
		/// The left view event handler.
		/// </summary>
		/// <param name="sender">
		/// The sender. 
		/// </param>
		/// <param name="e">
		/// The event arguments. 
		/// </param>
		private void LeftViewHandler(object sender, ExecutedRoutedEventArgs e)
		{
			if (this.IsModelUpDirectionY())
			{
				this.ChangeDirection(new Vector3D(1, 0, 0), new Vector3D(0, 1, 0));
			}
			else
			{
				this.ChangeDirection(new Vector3D(0, 1, 0), new Vector3D(0, 0, 1));
			}
		}
        

		/// <summary>
		///   Refreshes viewport.
		/// </summary>
		private void RefreshViewport()
		{
			// todo
		}

		/// <summary>
		/// Handles the reset command.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="e">The <see cref="ExecutedRoutedEventArgs" /> instance containing the event data.</param>
		private void ResetHandler(object sender, ExecutedRoutedEventArgs e)
		{
			this.Reset();
		}

		/// <summary>
		/// The right view event handler.
		/// </summary>
		/// <param name="sender">
		/// The sender. 
		/// </param>
		/// <param name="e">
		/// The event arguments. 
		/// </param>
		private void RightViewHandler(object sender, ExecutedRoutedEventArgs e)
		{
			if (this.IsModelUpDirectionY())
			{
				this.ChangeDirection(new Vector3D(-1, 0, 0), new Vector3D(0, 1, 0));
			}
			else
			{
				this.ChangeDirection(new Vector3D(0, -1, 0), new Vector3D(0, 0, 1));
			}
		}

		/// <summary>
		/// Handles the SetTarget command.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="e">The <see cref="ExecutedRoutedEventArgs" /> instance containing the event data.</param>
		private void SetTargetHandler(object sender, ExecutedRoutedEventArgs e)
		{
		}

		/// <summary>
		///   The stop animations.
		/// </summary>
		private void StopAnimations()
		{
			this.rotationSpeed = new Vector();
			this.panSpeed = new Vector3D();
            var zoomSpeed = 0;
		}

		/// <summary>
		/// The top view event handler.
		/// </summary>
		/// <param name="sender">
		/// The sender. 
		/// </param>
		/// <param name="e">
		/// The event arguments. 
		/// </param>
		private void TopViewHandler(object sender, ExecutedRoutedEventArgs e)
		{
			if (this.IsModelUpDirectionY())
			{
				this.ChangeDirection(new Vector3D(0, -1, 0), new Vector3D(0, 0, 1));
			}
			else
			{
				this.ChangeDirection(new Vector3D(0, 0, -1), new Vector3D(0, 1, 0));
			}
		}

		/// <summary>
		/// Updates the camera info.
		/// </summary>
		private void UpdateCameraInfo()
		{
			this.CameraInfo = this.Camera.GetInfo();
		}

		/// <summary>
		/// The update field of view info.
		/// </summary>
		private void UpdateFieldOfViewInfo()
		{
			var pc = this.Camera as PerspectiveCamera;
			this.FieldOfViewText = pc != null ? string.Format("FoV ∠ {0:0}°", pc.FieldOfView) : null;
		}

		/// <summary>
		/// The UseDefaultGestures property changed.
		/// </summary>
		private void UseDefaultGesturesChanged()
		{
			if (this.UseDefaultGestures)
			{
				//this.SetDefaultGestures();
			}
			else
			{
				this.InputBindings.Clear();
			}
		}

		/// <summary>
		/// Handles the zoom extents command.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="e">The <see cref="ExecutedRoutedEventArgs" /> instance containing the event data.</param>
		private void ZoomExtentsHandler(object sender, ExecutedRoutedEventArgs e)
		{
			this.ZoomExtents();
		}

		/// <summary>
		/// 
		/// </summary>
		private List<HitTestResult> mouseHitModels = new List<HitTestResult>();

		private BoundingBoxColoring[] boxesColorings;
		private SphereColoring sphereColoring;

		/// <summary>
		/// 
		/// </summary>
		/// <param name="e"></param>
		private void MouseDownHitTest(MouseEventArgs e)
		{
			var hits = this.FindHits(e.GetPosition(this)).Where(x => x.IsValid).ToArray();
			if (hits.Length > 0)
			{
				Mouse.Capture(this, CaptureMode.SubTree);
				foreach (var hit in hits)
				{
					hit.ModelHit.RaiseEvent(new MouseDown3DEventArgs(hit.ModelHit, hit, e.GetPosition(this), this));
					this.mouseHitModels.Add(hit);

					// the winner takes it all: only the nearest hit is taken!
					break;
				}
			}
		}

		public bool HittedSomething(MouseEventArgs e)
		{
			var hits = this.FindHits(e.GetPosition(this));
			if (hits.Count > 0)
				return true;
			return false;
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="e"></param>
		private void MouseUpHitTest(MouseEventArgs e)
		{
			if (mouseHitModels.Count > 0)
			{
				Mouse.Capture(this, CaptureMode.None);
				foreach (var hit in this.mouseHitModels)
				{
					hit.ModelHit.RaiseEvent(new MouseUp3DEventArgs(hit.ModelHit, hit, e.GetPosition(this), this));
				}
				this.mouseHitModels.Clear();
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="e"></param>
		private void MouseMoveHitTest(MouseEventArgs e)
		{
			if (mouseHitModels.Count > 0)
			{
				foreach (var hit in this.mouseHitModels)
				{
					hit.ModelHit.RaiseEvent(new MouseMove3DEventArgs(hit.ModelHit, hit, e.GetPosition(this), this));
				}
			}
		}

		private void MouseMoveHitTest(Point pt)
		{
			if (mouseHitModels.Count > 0)
			{
				foreach (var hit in this.mouseHitModels)
				{
					hit.ModelHit.RaiseEvent(new MouseMove3DEventArgs(hit.ModelHit, hit, pt, this));
				}
			}
		}

		public List<CuttingPlane> Planes { get; set; }
		public List<BoundingBoxColoring> BlockBoundingBoxes { get; set; }

		public SphereColoring SphereColoring
		{
			get { return sphereColoring; }
			set { sphereColoring = value; }
		}

		public CuttingPlane AddPlane(Color colors, Vector3 minP, Vector3 maxP, float distanceToCentreOfScene, Vector3 normal)
		{

			normal.Normalize();
			var randomR = new Random();
			var plane = new CuttingPlane(minP, maxP, normal, colors.ToColor4(), distanceToCentreOfScene);
			Planes.Add(plane);
			return plane;
		}

		public void RemovePlane(CuttingPlane plane)
		{
			Planes.Remove(plane);
		}


		public void ClearPlanes()
		{
			Planes.Clear();
		}

		public Bitmap MakePhoto(Action restore)
		{
			var args = new MakePhotoParameters()
			{
				Width = (int)ActualWidth,
				Height = (int)ActualHeight,
				//Camera = new OrthographicCamera()
				//{
				//	
				//};
				RestoreAction = restore,
			};

			return this.MakePhoto(args);
		}

		public Bitmap MakePhoto(MakePhotoParameters parameters)
		{
			var prevCamera = Camera;
			var prevDrawBG = IsBackgroundEnabled;
			var prepareAction = parameters.PrepareAction;
			var restoreAction = parameters.RestoreAction;
			parameters.RestoreAction = () =>
			{
				Camera = prevCamera;
				IsBackgroundEnabled = prevDrawBG;
				if (restoreAction != null)
					restoreAction();
			};
			parameters.PrepareAction = () =>
			{
				if (parameters.Camera != null)
					Camera = parameters.Camera;
				IsBackgroundEnabled = parameters.DrawBackground;
				if (prepareAction != null)
					prepareAction();
			};

			return this.RenderHost.MakePhoto(parameters);
		}
	}

	public class IlluminationSettings
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="IlluminationSettings"/> class.
		/// </summary>
		public IlluminationSettings()
		{
			Ambient = 0.32;
			Diffuse = 1.2;
			Light = 0.615;
			Shine = 0.1;
			Specular = 0.3;
		}

		public double Ambient { get; set; }
		public double Diffuse { get; set; }
		public double Specular { get; set; }
		public double Shine { get; set; }
		public double Light { get; set; }

		public void Assign(IlluminationSettings value)
		{
			Ambient = value.Ambient;
			Diffuse = value.Diffuse;
			Specular = value.Specular;
			Shine = value.Shine;
			Light = value.Light;
		}
	}
}