﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpDX.Direct3D11;

namespace HelixToolkit.Wpf.SharpDX.Controls.CustomTechniques {
	public class RenderPhongColorByBox :RenderTechnique {
		public RenderPhongColorByBox(string name) : base(name){}
		public override void UpdateVariables(Effect variables){
			
		}
	}
}
