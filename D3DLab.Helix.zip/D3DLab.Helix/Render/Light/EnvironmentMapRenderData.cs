using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpDX;
using SharpDX.Direct3D;
using SharpDX.Direct3D11;
using SharpDX.DXGI;

namespace HelixToolkit.Wpf.SharpDX.Render
{
	internal class EnvironmentMapRenderData : RenderData
	{
		private Buffer vertexBuffer;
		private Buffer indexBuffer;

		private ShaderResourceView texCubeMapView;

		private RasterizerState rasterState;
		private DepthStencilState depthStencilState;

		private MeshGeometry3D geometry;

		private int indicesCount;

		public EnvironmentMapRenderData(IRenderHost host)
			: base(host, Techniques.RenderCubeMap)
		{
		}

		public string Filename { get; set; }

		public bool IsActive { get; set; }

		protected override void AttachCore(RenderContext renderContext)
		{
			/// -- attach cube map 
			if (Filename != null && IsActive)
			{
				/// -- attach texture
				using (var texture = Texture2D.FromFile<Texture2D>(renderContext.Device, Filename))
				{
					this.texCubeMapView = new ShaderResourceView(renderContext.Device, texture);
				}
				renderContext.TechniqueContext.Variables.TexCubeMap.SetResource(this.texCubeMapView);
				renderContext.TechniqueContext.Variables.HasCubeMap.Set(true);

				/// --- set up geometry
				var sphere = new MeshBuilder(false, true, false);
				sphere.AddSphere(new Vector3(0, 0, 0));
				this.geometry = sphere.ToMeshGeometry3D();

				/// --- set up vertex buffer
				this.vertexBuffer = renderContext.Device.CreateBuffer(BindFlags.VertexBuffer, CubeVertex.SizeInBytes, this.geometry.Positions.Select((x, ii) => new CubeVertex() { Position = new Vector4(x, 1f) }).ToArray());

				/// --- set up index buffer
				this.indexBuffer = renderContext.Device.CreateBuffer(BindFlags.IndexBuffer, sizeof(int), geometry.Indices.ToArrayFast());

				this.indicesCount = geometry.Indices.Count;

				/// --- set up rasterizer states
				var rasterStateDesc = new RasterizerStateDescription()
				{
					FillMode = FillMode.Solid,
					CullMode = CullMode.Back,
					IsMultisampleEnabled = true,
					IsAntialiasedLineEnabled = true,
					IsFrontCounterClockwise = false,
				};
				this.rasterState = new RasterizerState(renderContext.Device, rasterStateDesc);

				/// --- set up depth stencil state
				var depthStencilDesc = new DepthStencilStateDescription()
				{
					DepthComparison = Comparison.LessEqual,
					DepthWriteMask = global::SharpDX.Direct3D11.DepthWriteMask.All,
					IsDepthEnabled = true,
				};
				this.depthStencilState = new DepthStencilState(renderContext.Device, depthStencilDesc);
			}
			else
			{
				renderContext.TechniqueContext.Variables.HasCubeMap.Set(false);
			}
		}

		protected override void DetachCore()
		{
			this.geometry = null;

			Disposer.RemoveAndDispose(ref this.vertexBuffer);
			Disposer.RemoveAndDispose(ref this.indexBuffer);
			Disposer.RemoveAndDispose(ref this.texCubeMapView);
			Disposer.RemoveAndDispose(ref this.rasterState);
			Disposer.RemoveAndDispose(ref this.depthStencilState);
		}

		protected override void RenderCore(RenderContext renderContext)
		{
			renderContext.Device.ImmediateContext.InputAssembler.InputLayout = renderContext.TechniqueContext.VertexLayout;
			renderContext.Device.ImmediateContext.InputAssembler.PrimitiveTopology = global::SharpDX.Direct3D.PrimitiveTopology.TriangleList;
			renderContext.Device.ImmediateContext.InputAssembler.SetIndexBuffer(this.indexBuffer, Format.R32_UInt, 0);
			renderContext.Device.ImmediateContext.InputAssembler.SetVertexBuffers(0, new VertexBufferBinding(this.vertexBuffer, CubeVertex.SizeInBytes, 0));

			renderContext.Device.ImmediateContext.Rasterizer.State = rasterState;
			renderContext.Device.ImmediateContext.OutputMerger.DepthStencilState = depthStencilState;

			/// --- set constant paramerers 
			var worldMatrix = Matrix.Translation(renderContext.CameraPosition);
			renderContext.TechniqueContext.Variables.World.SetMatrix(ref worldMatrix);

			/// --- render the geometry
			renderContext.TechniqueContext.EffectTechnique.GetPassByIndex(0).Apply(renderContext.Device.ImmediateContext);
			renderContext.Device.ImmediateContext.DrawIndexed(this.indicesCount, 0, 0);
		}
	}
}
