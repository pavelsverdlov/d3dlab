using System;
using System.Collections.Generic;
using System.Linq;

namespace HelixToolkit.Wpf.SharpDX.Controllers
{
	public enum AnimateAttenuation
	{
		Linear,
		Exp,
	}
}
