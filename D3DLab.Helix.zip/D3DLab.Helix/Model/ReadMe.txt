﻿
Q:
- should dependency properties be used?
- simple material model vs. shaders
- Visual3D/Model3D?

A:
- yes
- shaders
- Model3D