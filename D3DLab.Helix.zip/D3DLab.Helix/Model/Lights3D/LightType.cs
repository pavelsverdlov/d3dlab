using System;

namespace HelixToolkit.Wpf.SharpDX
{
	public enum LightType : ushort
	{
		Ambient = 1,
		Directional = 2,
		Point = 3,
		Spot = 4,
	}
}
