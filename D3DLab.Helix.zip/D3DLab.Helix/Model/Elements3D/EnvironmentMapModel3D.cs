using System.Linq;
using System.Windows;
using global::SharpDX;
using global::SharpDX.Direct3D11;
using global::SharpDX.DXGI;
using HelixToolkit.Wpf.SharpDX.Render;
using Direct3D = global::SharpDX.Direct3D;
using Matrix = global::SharpDX.Matrix;
using Texture2D = global::SharpDX.Direct3D11.Texture2D;

namespace HelixToolkit.Wpf.SharpDX
{
	public sealed class EnvironmentMap3D : Model3D
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="EnvironmentMap3D"/> class.
		/// </summary>
		public EnvironmentMap3D()
		{
		}

		/// <summary>
		/// 
		/// </summary>
		public static readonly DependencyProperty FilenameProperty =
			DependencyProperty.Register("Filename", typeof(string), typeof(EnvironmentMap3D), new UIPropertyMetadata(null));

		/// <summary>
		/// Gets or sets the current environment map texture image
		/// (expects DDS Environment Map image)
		/// </summary>
		public string Filename
		{
			get { return (string)this.GetValue(FilenameProperty); }
			set { this.SetValue(FilenameProperty, value); }
		}

		/// <summary>
		/// Indicates, if this element is active, if not, the model will be not 
		/// rendered and not reflected.
		/// default is true.
		/// </summary>
		public static readonly DependencyProperty IsActiveProperty =
			DependencyProperty.Register("IsActive", typeof(bool), typeof(Element3D), new UIPropertyMetadata(true));

		/// <summary>
		/// Indicates, if this element is active, if not, the model will be not 
		/// rendered and not reflected.
		/// default is true.
		/// </summary>
		public bool IsActive
		{
			get { return (bool)this.GetValue(IsActiveProperty); }
			set { this.SetValue(IsActiveProperty, value); }
		}

		internal override RenderData CreateRenderData(IRenderHost host)
		{
			return new EnvironmentMapRenderData(host);
		}

		public override void Update(RenderContext renderContext, System.TimeSpan timeSpan)
		{
			base.Update(renderContext, timeSpan);

			if (RenderData == null)
				return;
			var renderData = (EnvironmentMapRenderData)RenderData;

			renderData.IsActive = IsActive;
			renderData.Filename = Filename;
		}
	}
}
