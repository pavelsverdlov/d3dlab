﻿namespace HelixToolkit.Wpf.SharpDX
{
    //public class UIResizeManipulator3D : UIManipulator3D
    //{

    //    public UIResizeManipulator3D()
    //    { 
    //        this.e
    //    }

    //}
}
