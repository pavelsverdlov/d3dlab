﻿namespace HelixToolkit.Wpf.SharpDX
{
	public class Light3DCollection : GroupElement3D
	{
	}
}
