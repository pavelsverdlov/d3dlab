﻿using D3DLab.Std.Engine.Core;
using D3DLab.Std.Engine.Core.Shaders;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace D3DLab.Debugger.Windows {
    public sealed class ShaderEditorPopup {
        private ShaderEditor win;
        public ShaderEditorViewModel ViewModel { get; }

        public ShaderEditorPopup() {
            win = new ShaderEditor();
            ViewModel = (ShaderEditorViewModel)win.DataContext;
        }
        public void Show() {
            win.Show();
        }
    }

    public class EditorHistory {
        public void Undo() {

        }
        public void Redo() {

        }

        public void Clear() {
        }
    }

    public class ShaderSaveCommand : ICommand {
        private ShaderEditorViewModel shaderEditorViewModel;

        public ShaderSaveCommand(ShaderEditorViewModel shaderEditorViewModel) {
            this.shaderEditorViewModel = shaderEditorViewModel;
        }

        public event EventHandler CanExecuteChanged = (x, o) => { };
        public bool CanExecute(object parameter) { return true; }
        public void Execute(object parameter) {
            shaderEditorViewModel.Save();
        }
    }
   
    public class ShaderTabEditor : INotifyPropertyChanged {
        public class EditorWordSelectedCommand : ICommand {
            readonly Dictionary<string, List<Run>> words;
            readonly ShaderInterpreter Interpreter;
            string prev;
            public EditorWordSelectedCommand(Dictionary<string, List<Run>> words, ShaderInterpreter interpreter) {
                this.Interpreter = interpreter;
                this.words = words;
            }
            public event EventHandler CanExecuteChanged = (x, o) => { };
            public bool CanExecute(object parameter) { return true; }
            public void Execute(object parameter) {
                var world = parameter.ToString().Trim();
                if (!string.IsNullOrWhiteSpace(prev)) {
                    words[prev].ForEach(x => x.Background = Brushes.Transparent);
                    prev = null;
                }
                if (words.TryGetValue(world, out var item)) {
                    item.ForEach(x => x.Background = Brushes.LightBlue);
                    prev = world;
                }
            }
        }

        public string Header { get { return Info.Stage; } }
        public FlowDocument ShaderDocument { get; set; }
        public ICommand WordSelected { get; set; }

        public IShaderInfo Info { get; }

        private readonly Dictionary<string, List<Run>> words;
        //private ShaderInterpreter Interpreter;

        public ShaderTabEditor(IShaderInfo info) {
            this.Info = info;
            //ShaderDocument = new FlowDocument();
            words = new Dictionary<string, List<Run>>();
                     
        }
        public void LoadShaderAsync() {
            var text = Info.ReadText();

            var ast = new TestAST();
            ast.Parse(text);
            ShaderDocument = ast.Document;
            return;

            //var parser = new ShaderParser(text);

            //parser.Analyze();

            //ShaderDocument = parser.Document;
            //OnPropertyChanged(nameof(ShaderDocument));

            //Interpreter = parser.Interpreter;

            //WordSelected = new EditorWordSelectedCommand(words, Interpreter);
        }

        //private void Fill(string txt, Tokens token) {
        //    if (!words.TryGetValue(txt, out var item)) {
        //        words.Add(txt, new List<Run>());
        //    }

        //    Run run = new Run(txt);
        //    //switch (token) {
        //    //    case Tokens.Operator:
        //    //        run.Foreground = Brushes.Blue;
        //    //        break;
        //    //    case Tokens.Comments:
        //    //        run.Foreground = Brushes.Green;
        //    //        break;
        //    //    default:
        //    //        break;
        //    //}
        //   // par.Inlines.Add(run);
        //    words[txt].Add(run);
        //}

        public event PropertyChangedEventHandler PropertyChanged = (x, y) => { };
        private void OnPropertyChanged(string name) {
            PropertyChanged(this, new PropertyChangedEventArgs(name));
        }
    }

    public sealed class ShaderEditorViewModel {
        public ICollectionView Tabs { get; }
        private readonly ObservableCollection<ShaderTabEditor> tabs;
        public ICommand SaveCommand { get; }
        public ObservableCollection<string> Errors { get; set; }


        readonly EditorHistory history;
        IShaderEditingComponent current;
        IShaderCompilator compilator;

        public ShaderEditorViewModel() {
            tabs = new ObservableCollection<ShaderTabEditor>();
            Tabs = CollectionViewSource.GetDefaultView(tabs);
            history = new EditorHistory();
            SaveCommand = new ShaderSaveCommand(this);
            Errors = new ObservableCollection<string>();
        }

        public void LoadShader(IShaderEditingComponent com) {
            current = com;
            compilator = com.GetCompilator();
            history.Clear();

            foreach (var sh in compilator.Infos) {
                var tab = new ShaderTabEditor(sh);
                tabs.Add(tab);
                tab.LoadShaderAsync();
            }
            Tabs.MoveCurrentToFirst();

        }

        private ShaderTabEditor GetSelected() {
            return (ShaderTabEditor)Tabs.CurrentItem;
        }

        public void Save() {
            var selected = GetSelected();
            try {
                var shaderDocument = selected.ShaderDocument;
                string text = new TextRange(shaderDocument.ContentStart, shaderDocument.ContentEnd).Text;

                compilator.Compile(selected.Info, text);
                current.ReLoad();
                Errors.Insert(0, $"Compile: {selected.Info.Stage} succeeded");
            } catch (Exception ex) {
                foreach(var line in Regex.Split(ex.Message, Environment.NewLine)){
                    Errors.Insert(0,line);
                }
            }
        }
    }
}
