﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Media;

namespace D3DLab.Debugger.Windows {


    class NodeCollection : List<Node> { }

    abstract class Node {
        public readonly ASTTokens Token;
        protected Node(ASTTokens token) {
            Token = token;
        }
    }

    //Number,
    //String,
    //Boolean,
    //,
    class ValueNode : Node {
        public readonly LexerNode Value;
        public ValueNode(ASTTokens token, LexerNode val) : base(token) {
            Value = val;
        }
        public override string ToString() {
            return $"{Value}<{Token}>";
        }
    }



    class ConditionalNode : Node {
        public readonly Node If;
        public readonly Node Else;
        protected ConditionalNode() : base(ASTTokens.Conditional) {
        }
    }
    //BinaryExpression
    class OperatorNode : Node {
        public readonly string Operator; // '=', '+'
        public readonly Node Left;
        public readonly Node Right;
        public OperatorNode(Node left, Node right, string _operator, ASTTokens token) : base(token) {
            Left = left;
            Right = right;
            Operator = _operator;
        }

        public override string ToString() {
            return $"{Left} {Operator} {Right}";
        }
    }
    class AssignmentNode : OperatorNode {
        public AssignmentNode(Node left, Node right) : base(left, right, "=", ASTTokens.Assignment) {
        }
        public override string ToString() {
            return $"{Left} = {Right}";
        }
    }
    class SequenceNode : Node {
        public readonly NodeCollection Prog;
        public SequenceNode() : base(ASTTokens.Sequence) {
            Prog = new NodeCollection();
        }
    }


    class TypeIdentifierNode : Node {
        public LexerNode Type;
        public LexerNode Name;
        public LexerNode Description;
        public TypeIdentifierNode(LexerNode type, LexerNode name, ASTTokens token = ASTTokens.TypeIdentifier) : base(token) {
            Type = type;
            Name = name;
        }
        public override string ToString() {
            return $"{Type?.Value} {Name.Value} {(Description != null ? ": " + Description.Value : string.Empty)}";
        }
    }

    class IdentifierNode : Node {
        public readonly List<LexerNode> Name;
        public IdentifierNode() : base(ASTTokens.Identifier) {
            Name = new List<LexerNode>();
        }
        public IdentifierNode(LexerNode single) : base(ASTTokens.Identifier) {
            Name = new List<LexerNode> { single };
        }
        public override string ToString() {
            return Name.Count > 1 ? string.Join(".", Name.Select(x => x.Value)) : Name.Single().Value;
        }
    }


    class FunctionDeclarationNode : Node {
        public readonly Node Name;
        public readonly NodeCollection Vars; // input params in function
        protected FunctionDeclarationNode(Node name, ASTTokens token) : base(token) {
            Name = name;
            Vars = new NodeCollection();
        }

        //void ITest1.Add(Node node) {
        //    Vars.Add(node);
        //}
    }
    class FunctionNode : FunctionDeclarationNode {
        public readonly NodeCollection Body;
        public FunctionNode(TypeIdentifierNode name) : base(name, ASTTokens.FunctionDeclaration) {
            Body = new NodeCollection();
        }
    }
    class FunctionCallNode : Node {
        public readonly Node Func;
        public readonly NodeCollection Args;
        public FunctionCallNode(Node func) : base(ASTTokens.FunctionCall) {
            Func = func;
            Args = new NodeCollection();
        }

        public override string ToString() {
            return $"{Func}({string.Join(",", Args.Select(x => x.ToString()))})";
        }
    }
    class DeclarationNode : TypeIdentifierNode {
        public readonly NodeCollection Body;
        protected DeclarationNode(LexerNode type, LexerNode name, ASTTokens token) : base(type, name, token) {
            Body = new NodeCollection();
        }
    }
    class StructNode : DeclarationNode {
        public StructNode(LexerNode type, LexerNode name) : base(type, name, ASTTokens.StructDeclaration) {
        }
    }
    class CbufferNode : DeclarationNode {
        public FunctionCallNode Register;
        public CbufferNode(LexerNode type, LexerNode name) : base(type, name, ASTTokens.CbufferDeclaration) {
        }
    }

    //lexer
    /*
     { type: "punc", value: "(" }           // punctuation: parens, comma, semicolon etc.
{ type: "num", value: 5 }              // numbers
{ type: "str", value: "Hello World!" } // strings
{ type: "kw", value: "lambda" }        // keywords
{ type: "var", value: "a" }            // identifiers
{ type: "op", value: "!=" }            // operators
         */


    class AbstractSyntaxTreeShader : AbstractSyntaxTree {
        HashSet<string> typeDeclaration = new HashSet<string> {
             "struct", "cbuffer",
        };
        HashSet<string> types = new HashSet<string> {
            "float4x4", "float2", "float3", "float4", "int",
        };
        HashSet<string> keywords = new HashSet<string> {
             "return", "if", "else",
        };
        HashSet<string> allkeys = new HashSet<string>();
        HashSet<string> id_separator = new HashSet<string> {
            "=", ":",";"
        };
        public FlowDocument Document;
        readonly ShaderInterpreter interpreter;
        readonly SyntaxHighlighter highlighter;

        LexerNode lex;
        SequenceNode prog = new SequenceNode();

        public AbstractSyntaxTreeShader() {
            typeDeclaration.ForEach(x => allkeys.Add(x));
            keywords.ForEach(x => allkeys.Add(x));
            types.ForEach(x => allkeys.Add(x));

            Document = new FlowDocument();

            interpreter = new ShaderInterpreter();
            highlighter = new SyntaxHighlighter(Document, allkeys);



        }

        public void Parse(string text) {
            text = text.Replace(Environment.NewLine, "\n");
            Document.Blocks.Add(new Paragraph(new Run(text)));
            //
            var la = new LexicalAnalyzer(allkeys);
            la.Parse(Document.ContentStart, text);
            var lexer = la.Lexers;
            //
            try {
                while (lexer.Any()) {
                    lex = lexer.Dequeue();
                    Node node = null;
                    switch (lex.Token) {
                        case LexerTokens.Keyword:
                            switch (lex.Value) {
                                case "struct":
                                    var sn = new StructNode(lex, lexer.Dequeue());
                                    DelimitedBy(lexer, DelimeterPrams.Sequences, sn.Body, IdentifierParser);

                                    // interpreter.RegisterNewObject(sn);
                                    highlighter.Apply(sn);

                                    node = sn;
                                    break;
                                case "cbuffer":
                                    var bn = new CbufferNode(lex, lexer.Dequeue());
                                    var registrOp = lexer.Dequeue();
                                    if (registrOp.Token != LexerTokens.Operator) {
                                        throw new SyntaxException(registrOp);
                                    }
                                    // : register(b1) type is null for now
                                    var _registerFunc = new IdentifierNode(lexer.Dequeue());
                                    bn.Register = new FunctionCallNode(_registerFunc);
                                    //
                                    DelimitedBy(lexer, DelimeterPrams.Function, bn.Register.Args, FuncArgsParser);
                                    DelimitedBy(lexer, DelimeterPrams.Sequences, bn.Body, IdentifierParser);

                                    highlighter.Apply(bn);

                                    node = bn;
                                    break;
                            }
                            break;
                        case LexerTokens.Identifier:
                            // global function: GSInputLS VShaderLines(VSInputLS input, ... ) { ... }
                            // float4 vLineParams = float4(4, 1, 0, 0);



                            var funNmae = new TypeIdentifierNode(lex, lexer.Dequeue());

                            var glfun = new FunctionNode(funNmae);

                            DelimitedBy(lexer, DelimeterPrams.Function, glfun.Vars, FuncVarsParser);
                            DelimitedBy(lexer, DelimeterPrams.Sequences, glfun.Body, IdentifierParser);

                            highlighter.Apply(glfun);

                            node = glfun;
                            break;
                        case LexerTokens.Comment:
                            highlighter.Apply(lex);
                            break;
                        case LexerTokens.Punctuation:
                            continue;
                    }

                    prog.Prog.Add(node);

                }
            } catch (SyntaxException se) {
                highlighter.Apply(se);
            }
        }




        Node FuncVarsParser(Queue<LexerNode> lexers) {
            if (lexers.Count != 2) {
                throw new SyntaxException(lexers.Dequeue());
            }
            return new TypeIdentifierNode(lexers.Dequeue(), lexers.Dequeue());
        }
        Node FuncArgsParser(Queue<LexerNode> lexers) {
            if (lexers.Count > 1) {
                throw new SyntaxException(lexers.Dequeue());
            }
            return new IdentifierNode(lexers.Dequeue());
        }
        Node IdentifierParser(Queue<LexerNode> lexers) {
            var precedences = new Dictionary<string, int> {
                { "=", 1}, {"||", 2}, { "&&", 3 },
                { "<", 7 }, {">", 7 }, {"<=", 7 }, {">=", 7 }, {"==", 7 }, {"!=", 7 },
                { "+", 10 }, {"-", 10 }, { "*", 20 }, {"/", 20 },{ "%", 20 },
            };

            var left = new Queue<LexerNode>();
            LexerNode op = null;
            while (lexers.Any()) {
                var lex = lexers.Dequeue();
                if (lex.Token == LexerTokens.Operator) {
                    op = lex;
                    break;
                }
                left.Enqueue(lex);
            }
            //analyze left part
            Node leftNode = null;
            if (left.Count == 1) {
                var id = new IdentifierNode();
                id.Name.Add(left.Dequeue());
                leftNode = id;
            } else if (left.Any(x => x.Token == LexerTokens.Punctuation)) {
                //maybe function call:  mul(World, inputp);
                var func = left.Dequeue();
                switch (left.Peek().Value) {
                    case ".":
                        //or just variable, example: 'output.p'
                        var id = new IdentifierNode();
                        id.Name.Add(func);
                        while (left.Any()) {
                            var l = left.Dequeue();
                            if (l.Token == LexerTokens.Punctuation) {
                                continue;
                            }
                            id.Name.Add(l);
                        }
                        leftNode = id;
                        break;
                    case "(":// for sure this is call
                        //'null' should be replaced to real functon returned type! 
                        var glfun = new FunctionCallNode(new TypeIdentifierNode(null, func));
                        DelimitedBy(left,
                           new DelimeterPrams { start = "(", stop = ")", separator = "," },
                           glfun.Args, IdentifierParser);
                        leftNode = glfun;
                        break;
                }
            } else if (left.Any(x => x.Token == LexerTokens.Keyword) || left.All(x => x.Token == LexerTokens.Identifier)) { //example: 'float4 inputp'
                leftNode = new TypeIdentifierNode(left.Dequeue(), left.Dequeue());
            } else { //Binary expressions : 'x + y * z;
                var lex = left.Dequeue();
                switch (lex.Token) {
                    case LexerTokens.Number:
                        leftNode = new ValueNode(ASTTokens.Number, lex);
                        break;
                    case LexerTokens.Identifier:
                        var id = new IdentifierNode();
                        id.Name.Add(lex);
                        leftNode = id;
                        break;
                }
            }

            System.Diagnostics.Debug.Assert(!left.Any());

            if (op == null) {
                return leftNode;
            }

            return op.Value == "=" ?
                new AssignmentNode(leftNode, IdentifierParser(lexers)) :
                new OperatorNode(leftNode, IdentifierParser(lexers), op.Value, ASTTokens.BinaryExpression);
        }



        //protected TNode CreateNode<TNode>(ASTTokens token) where TNode : Node {
        //    switch (token) {
        //        case ASTTokens.StructDeclaration:

        //            break;
        //    }
        //    return null;
        //}

        protected override void OnIgnored(LexerNode lex) {
            highlighter.Apply(lex);
        }
    }

    class SyntaxException : Exception {
        public LexerNode Lexer { get; }

        public SyntaxException(LexerNode current) {
            Lexer = current;
        }
    }

    enum ASTTokens {
        Number,
        String,
        Boolean,
        Identifier,
        TypeIdentifier,
        FunctionDeclaration,
        FunctionCall,
        Assignment,
        Conditional,
        BinaryExpression,
        Sequence,
        StructDeclaration,
        CbufferDeclaration,
    }

    class TestAST : AbstractSyntaxTree {
        HashSet<string> objects = new HashSet<string> {
            "struct","cbuffer"
        };
        HashSet<string> array = new HashSet<string> {
             "float2", "float3", "float4",
        };
        HashSet<string> primitive = new HashSet<string> {
            "int","return"
        };
        HashSet<string> matrix = new HashSet<string> {
            "float4x4",
        };

        #region common
        public class ListNode : List<Node> { }
        public class Node {
            public Node Parent;
        }
        public class CommentsNode : Node {
            public LexerNode Lex;
        }
        //
        public class DefinitionObjectNode : Node {
            public ListNode Children = new ListNode();
        }
        public abstract class DeclarationOrDefinistion : DefinitionObjectNode {
            public DatatypeNode TypeNode;

        }
        public class DefinitionNode : DefinitionObjectNode {
            public List<LexerNode> VarNamesLex = new List<LexerNode>();

            public override string ToString() {
                var sb = new StringBuilder();
                //if (TypeNode != null) {
                //    sb.Append(TypeNode.ToString()).Append(' ');
                //}
                VarNamesLex.ForEach(x => sb.Append(x.Value).Append('.'));
                return sb.ToString();
            }
        }


        public class DeclarationNode : DeclarationOrDefinistion {
            public Node DefinitionName;

            public override string ToString() {
                var sb = new StringBuilder();
                if (TypeNode != null) {
                    sb.Append(TypeNode.ToString()).Append(' ');
                }
                sb.Append(DefinitionName.ToString());
                return sb.ToString();
            }
        }

        public class VariableDeclaration : DeclarationNode {

        }
        public class AssignmentVariableDeclaration : VariableDeclaration {
            public Node Right;

            public override string ToString() {
                var sb = new StringBuilder();
                if (TypeNode != null) {
                    sb.Append(TypeNode.ToString()).Append(' ');
                }
                sb.Append(DefinitionName.ToString());
                sb.Append('=');
                sb.Append(Right.ToString());
                return sb.ToString();
            }
        }
        public class StructVariableDeclaration : VariableDeclaration {
            // example: [InterpolationModifier] Type[RxC] MemberName [:Semantic];

            /// <summary>
            /// Optional parameter-usage information, used by the compiler to link shader inputs and outputs. There are several predefined semantics for vertex and pixel shaders. The compiler ignores semantics unless they are declared on a global variable, or a parameter passed into a shader.
            /// https://msdn.microsoft.com/en-us/library/windows/desktop/bb509647(v=vs.85).aspx
            /// </summary>
            public LexerNode SemanticNameLex;
        }
        public class StructNode : DeclarationNode { }
        public class CBufferNode : DeclarationNode {
            public Node Register;
        }
        public class FunctionDeclarationNode : DeclarationNode {
            public LexerNode SemanticNameLex;
            public ListNode Vars = new ListNode();
            public override string ToString() {
                var sb = new StringBuilder();
                sb.Append(base.ToString());
                sb.Append('(');
                Vars.ForEach(x => sb.Append(x.ToString()).Append(','));
                sb.Append(')');
                return sb.ToString();
            }
        }
        //
        public class TypeNode : Node {
            public LexerNode TypeLex;
            public override string ToString() {
                return TypeLex.Value;
            }
        }
        public class DatatypeNode : TypeNode {
        }
        public class PrimitiveType : DatatypeNode { }
        public class ArrayType : DatatypeNode {// float2 float3 float4
        }
        //
        public class ExpressionNode : Node {

        }
        public class FunctionCallNode : ExpressionNode {
            public Node Name;
            public ListNode Args = new ListNode();
            public override string ToString() {
                var sb = new StringBuilder();
                sb.Append(Name.ToString());
                sb.Append('(');
                Args.ForEach(x => sb.Append(x.ToString()).Append(','));
                sb.Append(')');
                return sb.ToString();
            }
        }
        public class VariableExpression : ExpressionNode {

        }
        public class BinaryExpression : ExpressionNode {
            public ExpressionNode Left;
            public ExpressionNode Right;
        }
        //
        public class StatementNode : Node { }
        public class IfStatementNode : StatementNode { }
        public class LoopStatementNode : StatementNode { }
        //
        public class OtherSyntaxObject { }

        #endregion

        ShaderInterpreter interpreter;
        SyntaxHighlighter highlighter;
        public FlowDocument Document;
        public TestAST() {
            interpreter = new ShaderInterpreter();
            //
        }

        public void Parse(string text) {
            Document = new FlowDocument();
            text = text.Replace(Environment.NewLine, "\n");
            Document.Blocks.Add(new Paragraph(new Run(text)));
            //
            var la = new LexicalAnalyzer(new HashSet<string>(array.Union(primitive).Union(matrix).Union(objects)));
            la.Parse(Document.ContentStart, text);
            var lexer = la.Lexers;
            //
            try {
                DefinitionObjectNode prog = new DefinitionObjectNode();
                while (lexer.Any()) {
                    var node = DoDParse(lexer, prog);
                    prog.Children.Add(node);
                }

                highlighter = new SyntaxHighlighter(Document, new HashSet<string>(array.Union(primitive).Union(matrix).Union(objects)));
                highlighter.Apply(prog);
            } catch (Exception ex) {
                ex.ToString();
            }
        }

        Node DoDParse(Queue<LexerNode> lexers, Node parent) {
            //  while (lexers.Any()) {
            Node current = null;
            var isKey = false;
            var next = lexers.Peek();
            switch (next.Token) {
                case LexerTokens.Comment:
                    return new CommentsNode() { Lex = lexers.Dequeue() };
                case LexerTokens.Keyword:
                    // ==== examples ==== //
                    //struct GSInputLS {} 
                    //cbuffer ProjectionBuffer {}     
                    // ==== ++++++++ ==== //
                    isKey = true;
                    break;
                case LexerTokens.Identifier:
                    // ==== examples ==== //
                    //GSInputLS VShaderLines(VSInputLS input) {
                    // ==== ++++++++ ==== //
                    if (interpreter.NewKeys.Contains(next.Value)) {
                        isKey = true;
                        break;
                    }
                    // ==== examples ==== //
                    // output.p = mul(World, inputp);
                    // ==== ++++++++ ==== //
                    var declarationLexers = DelimitedBy(lexers, DelimeterParams.VarDeclaration);
                    current = ExpressionParse(declarationLexers, parent);
                    break;
                default:

                    break;
            }

            if (isKey) {
                var typen = TypeParse(lexers.Dequeue());
                var name = new DefinitionNode();
                name.VarNamesLex.Add(lexers.Dequeue());
                DeclarationOrDefinistion dod;

                if (!lexers.Any()) {//simple declaration
                    //float4x4 Projection;
                    dod = new VariableDeclaration { DefinitionName = name };
                } else {
                    switch (next.Value) {
                        case "struct":
                            interpreter.RegisterStruct(name.VarNamesLex.First());
                            dod = new StructNode { DefinitionName = name };
                            DelimitedBy(lexers, DelimeterParams.Sequences, dod.Children,
                                lex => DoDParse(lex, dod));
                            if (lexers.Peek().Value == ";") {
                                //in some cases ';' is end of declaration 
                                lexers.Dequeue();
                            }
                            break;
                        case "cbuffer":
                            var cbn = new CBufferNode { DefinitionName = name };
                            if (lexers.Dequeue().Value != ":") {
                                throw new SyntaxException(lexers.Dequeue());
                            }
                            cbn.Register = CallFunctionParse(lexers, cbn);
                            DelimitedBy(lexers, DelimeterParams.Sequences, cbn.Children,
                                lex => DoDParse(lex, cbn));
                            dod = cbn;
                            break;
                        default:
                            var op = lexers.Peek();
                            // ==== examples ==== //
                            //int foo(InputT input, ...) { }
                            //float4 vLineParams = float4(4, 1, 0, 0);
                            //float4 c	: COLOR0;
                            // ==== ++++++++ ==== //
                            switch (op.Token) {
                                case LexerTokens.Operator://variable declaration
                                    var declarationLexers = DelimitedBy(lexers, DelimeterParams.VarDeclaration);

                                    dod = VarDeclarationParse(name, declarationLexers);
                                    break;
                                case LexerTokens.Punctuation:// function declaration
                                    var fdn = new FunctionDeclarationNode {
                                        DefinitionName = name
                                    };
                                    DelimitedBy(lexers, DelimeterParams.Function, fdn.Vars,
                                        lex => {
                                            var dn = new DefinitionNode();
                                            var v = new VariableDeclaration {
                                                Parent = fdn, TypeNode = TypeParse(lex.Dequeue()),
                                                DefinitionName = dn
                                            };
                                            dn.VarNamesLex.Add(lex.Dequeue());
                                            if (lex.Any()) {
                                                throw new SyntaxException(lex.Dequeue());
                                            }
                                            return v;
                                        });

                                    //maybe have semantic name
                                    var semanticNameMaybe = lexers.Peek();
                                    if (semanticNameMaybe.Token == LexerTokens.Operator && semanticNameMaybe.Value == ":") {
                                        lexers.Dequeue();//skip operator
                                        fdn.SemanticNameLex = lexers.Dequeue();
                                    }

                                    DelimitedBy(lexers, DelimeterParams.Sequences, fdn.Children,
                                        lex => DoDParse(lex, fdn));

                                    dod = fdn;
                                    break;
                                default:
                                    dod = null;
                                    break;
                            }

                            break;
                    }
                }
                typen.Parent = dod;
                dod.TypeNode = typen;
                current = dod;
            }

            current.Parent = parent;
            return current;
            // }
        }

        VariableDeclaration VarDeclarationParse(Node name, Queue<LexerNode> right) {
            // ==== examples ==== //
            //float4 vLineParams = float4(4, 1, 0, 0);
            //float4x4 Projection;
            //float4 c	: COLOR0;
            // ==== ++++++++ ==== //
            VariableDeclaration vd = new VariableDeclaration();
            switch (right.Dequeue().Value) {
                case "=":
                    //float4 vLineParams = float4(4, 1, 0, 0);
                    AssignmentVariableDeclaration avd = new AssignmentVariableDeclaration();
                    avd.Right = ExpressionParse(right, avd);
                    vd = avd;
                    break;
                case ":":
                    var svd = new StructVariableDeclaration();
                    svd.SemanticNameLex = right.Dequeue();
                    vd = svd;
                    break;
            }

            vd.DefinitionName = name;

            return vd;
        }

        Node ExpressionParse(Queue<LexerNode> lexers, Node parent) {
            var left = new Queue<LexerNode>();
            LexerNode op = null;
            while (lexers.Any()) {
                var lex = lexers.Dequeue();
                if (lex.Token == LexerTokens.Operator) {
                    op = lex;
                    break;
                }
                left.Enqueue(lex);
            }

            var leftExp = CallFunctionParse(left, parent);

            var right = lexers;
            if (!right.Any()) { // no expression in right side
                return leftExp;
            }

            VariableDeclaration vd = new VariableDeclaration();
            switch (op.Value) {
                case "=":
                    //float4 vLineParams = float4(4, 1, 0, 0);
                    AssignmentVariableDeclaration avd = new AssignmentVariableDeclaration();
                    avd.Right = ExpressionParse(right, avd);
                    avd.DefinitionName = leftExp;
                    vd = avd;
                    break;
                default:
                    break;

            }



            return vd;
        }

        DatatypeNode TypeParse(LexerNode lex) {
            DatatypeNode typen = new DatatypeNode();
            if (array.Contains(lex.Value)) {
                typen = new ArrayType();
            } else if (primitive.Contains(lex.Value)) {
                typen = new PrimitiveType();
            }
            typen.TypeLex = lex;
            return typen;
        }

        Node CallFunctionParse(Queue<LexerNode> lexers, Node parent) {
            var names = new List<LexerNode> { lexers.Dequeue() };
            LexerNode next = null;
            while (lexers.Any()) {
                next = lexers.Dequeue();
                switch (next.Token) {
                    case LexerTokens.Punctuation:
                        switch (next.Value) {
                            case ".": // = foo.xyz
                                names.Add(lexers.Dequeue());
                                break;
                            case "(":
                                // = clas.foo(4, 1, 0, 0);
                                
                                var func = new FunctionCallNode() { Parent = parent };
                                Node node;
                                if (names.Count == 1 && (names[0].Token == LexerTokens.Keyword || interpreter.NewKeys.Contains(names[0].Value))) {
                                    //= float4(4, 1, 0, 0); //like function call but it's creation
                                    node = TypeParse(names[0]);
                                } else {
                                    var def = new DefinitionNode();
                                    def.VarNamesLex.AddRange(names);
                                    node = def;
                                }

                                func.Name = node;
                                var pr = DelimeterParams.Function;
                                pr.IsStart = null;//ignore star because this lex was already processed 
                                DelimitedBy(lexers, pr, func.Args, lex => CallFunctionParse(lex, func));
                                return func;
                        }
                        break;
                }
            }
            var name = new DefinitionNode();
            name.VarNamesLex.AddRange(names);
            return name;
        }

        DefinitionNode DefinitionWithDot(Queue<LexerNode> lexers) {
            var def = new DefinitionNode();
            var needPunc = false;
            while (lexers.Any()) {
                var next = lexers.Peek();
                if (needPunc && !(next.Token == LexerTokens.Punctuation && next.Value == ".")) {
                    break;
                }
                def.VarNamesLex.Add(next);
                lexers.Dequeue();
            }
            return def;
        }

        Queue<LexerNode> DelimitedBy(Queue<LexerNode> lexer, DelimeterParams _params) {
            //var next = lexer.Dequeue();
            //if (next.Token != LexerTokens.Punctuation && next.Value != _params.start) {//incorect declaration
            //    throw new SyntaxException(next);
            //}
            var next = lexer.Dequeue();
            var blocks = new Queue<LexerNode>();
            while (!_params.IsStop(next)) {
                switch (next.Token) {
                    case LexerTokens.Punctuation:
                        if (_params.IsSeparator(next)) {
                            continue;
                        }
                        if (_params.IsStop(next)) {
                            break;
                        }
                        break;
                    case LexerTokens.Comment:
                        OnIgnored(next);
                        continue;
                }
                blocks.Enqueue(next);
                if (!lexer.Any()) {
                    break;
                }
                next = lexer.Dequeue();
            }
            return blocks;
        }
        void DelimitedBy(Queue<LexerNode> lexer,
            DelimeterParams _params,
            ListNode node,
            Func<Queue<LexerNode>, Node> parser) {
            if (_params.IsStart != null && !_params.IsStart(lexer.Dequeue())) {//incorect declaration
                throw new SyntaxException(lexer.Peek());
            }
            var blocks = new Queue<LexerNode>();
            LexerNode next;
            do {
                next = lexer.Dequeue();

                if (next.Token == LexerTokens.Comment) {
                    OnIgnored(next);
                    continue;
                }

                if (_params.IsSeparator(next) || _params.IsStop(next) || !lexer.Any()) {
                    if (blocks.Any()) {
                        node.Add(parser(blocks));
                    }
                    continue;
                }

                blocks.Enqueue(next);
            } while (!_params.IsStop(next) && lexer.Any());

            /*
            while (!_params.IsStop(next)) {
                next = lexer.Dequeue();
                switch (next.Token) {
                    case LexerTokens.Punctuation:
                        if (_params.IsSeparator(next)) {
                            if (blocks.Any()) {
                                node.Add(parser(blocks));
                            }
                            continue;
                        }
                        if (_params.IsStop(next)) {
                            if (blocks.Any()) {
                                node.Add(parser(blocks));
                            }
                            return;
                        }
                        break;
                    case LexerTokens.Comment:
                        OnIgnored(next);
                        continue;
                }
                blocks.Enqueue(next);
                if (!lexer.Any()) {
                    break;
                }

            }
            */

        }

        public class DelimeterParams {
            public static DelimeterParams Function {
                get {
                    return new DelimeterParams {
                        IsStart = new Func<LexerNode, bool>(lex => lex.Value == "("),
                        IsStop = new Func<LexerNode, bool>(lex => lex.Value == ")"),
                        IsSeparator = new Func<LexerNode, bool>(lex => lex.Value == ",")
                    };
                }
            }
            public static DelimeterParams Sequences {
                get {
                    return new DelimeterParams {
                        IsStart = new Func<LexerNode, bool>(lex => lex.Value == "{"),
                        IsStop = new Func<LexerNode, bool>(lex => lex.Value == "}"),
                        IsSeparator = new Func<LexerNode, bool>(lex => lex.Value == ";")
                    };
                }
            }
            public static DelimeterParams VarDeclaration {
                get {
                    return new DelimeterParams {
                        IsStop = new Func<LexerNode, bool>(lex => lex.Value == ";")
                    };
                }
            }
            public Func<LexerNode, bool> IsStart = new Func<LexerNode, bool>(lex => false);
            public Func<LexerNode, bool> IsStop = new Func<LexerNode, bool>(lex => false);
            public Func<LexerNode, bool> IsSeparator = new Func<LexerNode, bool>(lex => false);
            public Func<LexerNode, bool> Is = new Func<LexerNode, bool>(lex => false);
        }

        /*
        Node _Parser(Queue<LexerNode> lexers) {
            var list = new NodeCollection();
            var sequence = new Queue<LexerNode>();
            bool isKey = false;
            var next = lexers.Dequeue();
            
            switch (next.Token) {
                case LexerTokens.Keyword:
                    throw new SyntaxException(next);
                case LexerTokens.Identifier:
                    isKey = true;
                    sequence.Enqueue(next);
                    break;
            }
            next = lexers.Dequeue();
            switch (next.Token) {
                case LexerTokens.Punctuation:
                    switch (next.Value) {
                        case "(": // for sure this is call
                            if (isKey) {//incitialization of something
                                //float4(4, 1, 0, 0);                                
                                DelimitedBy(lexers, DelimeterPrams.Function, list, _Parser);
                            }
                            break;
                        case ".": //
                            break;
                        case ":":
                            DelimitedBy(lexers, DelimeterPrams.Sequences, list, IdentifierParser);
                            //float4 p : SV_Position;
                            //cbuffer ProjectionBuffer : register(b0)
                            break;
                        case "{":
                            break;
                    }
                    break;
                case LexerTokens.Operator:
                    break;
                default:
                    throw new SyntaxException(next);
            }

            return null;
        }
        */
        void Analzyze(TypeIdentifierNode node, Queue<LexerNode> lexers) {
            var next = lexers.Dequeue();
            switch (next.Token) {
                case LexerTokens.Punctuation:
                    switch (next.Value) {
                        case "(": // for sure this is call
                            break;
                        case ".": //
                            break;
                        case ":":
                            //float4 p : SV_Position;
                            //cbuffer ProjectionBuffer : register(b0)
                            break;
                        case "{":
                            break;
                    }
                    break;
                case LexerTokens.Operator:
                    break;
                default:
                    throw new SyntaxException(next);
            }
        }

        protected override void OnIgnored(LexerNode lex) {
            //throw new NotImplementedException();
        }
    }

    abstract class AbstractSyntaxTree {

        public struct DelimeterPrams {
            public static DelimeterPrams Function = new DelimeterPrams { start = "(", stop = ")", separator = "," };
            public static DelimeterPrams Sequences = new DelimeterPrams { start = "{", stop = "}", separator = ";" };

            public string start;
            public string stop;
            public string separator;
        }

        protected void DelimitedBy(Queue<LexerNode> lexer, DelimeterPrams _params,
            NodeCollection node,
            Func<Queue<LexerNode>, Node> parser) {
            var next = lexer.Dequeue();
            if (next.Token != LexerTokens.Punctuation && next.Value != _params.start) {//incorect declaration
                throw new SyntaxException(next);
            }
            var blocks = new Queue<LexerNode>();
            while (next.Value != _params.stop) {
                next = lexer.Dequeue();

                switch (next.Token) {
                    case LexerTokens.Punctuation:
                        if (next.Value == _params.separator) {
                            node.Add(parser(blocks));
                            continue;
                        }
                        if (next.Value == _params.stop) {
                            if (blocks.Any()) {
                                node.Add(parser(blocks));
                            }
                            return;
                        }
                        break;
                    case LexerTokens.Comment:
                        OnIgnored(next);
                        continue;
                }
                blocks.Enqueue(next);
            }
            node.Add(parser(blocks));
        }

        protected abstract void OnIgnored(LexerNode lex);

    }


    enum LexerTokens {
        Punctuation,    // { } , ; .
        Number,
        String,
        Keyword,        // struct, cbuffer, float4, 
        Identifier,
        Operator,       // '+' '!=' 
        Comment,

    }
    class LexerNode {
        public readonly LexerTokens Token;
        public readonly string Value;
        public readonly TextPointer TextPointer;
        public LexerNode(LexerTokens token, string value, TextPointer start) {
            System.Diagnostics.Contracts.Contract.Ensures(start == null);
            if (start == null) {

            }
            Token = token;
            Value = value;
            TextPointer = start;
        }
        public override string ToString() {
            return $"{Token} '{Value}'";
        }
    }
    class LexicalAnalyzer {

        public readonly Queue<LexerNode> Lexers;
        readonly HashSet<string> allkeys;
        //int pos = 1;
        int line = 1;
        int index = 0;
        int col = 0;

        TextPointer startPointer;

        public LexicalAnalyzer(HashSet<string> allkeys) {
            Lexers = new Queue<LexerNode>();
            this.allkeys = allkeys;
        }

        public void Parse(TextPointer startPointer, string text) {
            this.startPointer = startPointer;


            var builder = new StringBuilder();

            for (; index < text.Length; index++) {
                char _char = text[index];
                // pos++;

                builder.Append(_char);

                if (char.IsWhiteSpace(_char)) {
                    switch (_char) {
                        case '\n':
                            line++;
                            break;
                    }
                    // pos += 1;
                    continue;
                }
                if (IsComments(ref _char, ref text)) {
                    continue;
                }

                if (char.IsDigit(_char)) {
                    var val = FindTextBy(GetEnumerator(text, index), x => !char.IsDigit(x)).ToString();
                    Lexers.Enqueue(new LexerNode(LexerTokens.Number, val, GetCurrentPoiter(val)));

                    //  pos += val.Length;
                    index += val.Length - 1;
                    continue;
                }

                if (IsText(ref _char)) {
                    var val = FindTextBy(GetEnumerator(text, index), x => !IsTextOrDigit(ref x)).ToString();

                    //if this is not keyword than identifier
                    Lexers.Enqueue(new LexerNode(allkeys.Contains(val) ? LexerTokens.Keyword : LexerTokens.Identifier,
                        val, GetCurrentPoiter(val)));

                    // pos += val.Length;
                    index += val.Length - 1;
                    continue;
                }

                if ("+-*/%=&|<>!:".IndexOf(_char) > 0) {
                    // ':' end of property declaration
                    Lexers.Enqueue(new LexerNode(LexerTokens.Operator, _char.ToString(), GetCurrentPoiter(_char.ToString())));
                    continue;
                }

                if (char.IsPunctuation(_char)) {//,;(){}[]
                    Lexers.Enqueue(new LexerNode(LexerTokens.Punctuation, _char.ToString(), GetCurrentPoiter(_char.ToString())));
                    //  pos += 1;
                    continue;
                }

            }
        }

        void UpdateIndexes(char[] chars) {
            //  pos += chars.Length;
            index += chars.Length - 1;
        }

        bool IsComments(ref char _char, ref string text) {
            if (_char == '/' && text[index + 1] == '*') {
                var endChars = 2;
                var val = FindTextBy(GetEnumerator(text, index), endChars, x => x[0] == '*' && x[1] == '/').ToString();
                var lenght = val.Length + 1 + endChars;
                Lexers.Enqueue(new LexerNode(LexerTokens.Comment, val, GetCurrentPoiter(val)));
                //   pos += lenght - 1;
                index += lenght - 1;
                return true;
            }
            if (_char == '/' && text[index + 1] == '/') {
                var val = FindTextBy(GetEnumerator(text, index), x => x == '\n').ToString();
                line++;
                Lexers.Enqueue(new LexerNode(LexerTokens.Comment, val, GetCurrentPoiter(val)));
                //  pos += val.Length - 1;
                index += val.Length - 1;
                return true;
            }
            return false;
        }

        TextPointer GetCurrentPoiter(string val) {
            var pointer = startPointer.GetPositionAtOffset(index + 2, LogicalDirection.Backward);

            //debug
            //var d = new TextRange(
            //    startPointer.GetPositionAtOffset(index + 2, LogicalDirection.Backward),
            //    startPointer.GetPositionAtOffset(index + 2, LogicalDirection.Forward).GetPositionAtOffset(val.Length)
            //    ).Text;

            var range = new TextRange(pointer, pointer.GetPositionAtOffset(val.Length, LogicalDirection.Forward));
            if (range.Text != val) {

            }
            //

            return pointer;
        }

        static bool IsText(ref char _char) {
            return char.IsLetter(_char) || _char == '_';
        }
        static bool IsTextOrDigit(ref char _char) {
            return char.IsLetterOrDigit(_char) || _char == '_';
        }

        static StringBuilder FindTextBy(IEnumerator<char> enu, Func<char, bool> predicate) {
            var sb = new StringBuilder();
            while (enu.MoveNext()) {//get all name letters 
                var currrent = enu.Current;
                if (predicate(currrent)) {
                    break;
                }
                sb.Append(currrent);
            }
            return sb;
        }

        static StringBuilder FindTextBy(IEnumerator<char> enu, int count, Func<char[], bool> predicate) {
            var sb = new StringBuilder();
            var chars = new char[count];
            var index = 0;
            while (enu.MoveNext()) {//get all name letters 
                var currrent = enu.Current;

                chars[index] = currrent;
                index++;

                if (index == count) {
                    if (predicate(chars)) {
                        break;
                    }
                    index = 0;
                    sb.Append(chars);
                }
            }
            return sb;
        }
        static IEnumerator<char> GetEnumerator(string text, int start) {
            for (int i = start; i < text.Length; i++) {
                char ch = text[i];
                yield return ch;
            }
        }
    }



    public class ShaderInterpreter {
        public HashSet<string> NewKeys { get { return new HashSet<string>(global.Keys); } }

        //private readonly Dictionary<string, GloalObject> global = new Dictionary<string, GloalObject>();
        private readonly Dictionary<string, GloalObject> global = new Dictionary<string, GloalObject>();

        public ShaderInterpreter() {
        }

        class GloalObject { // fuction / cbuffer / struct / property
            public LexerNode Name;
        }

        //internal void RegisterNewObject(StructNode sn) {//cbuffer, struct
        //    global.Add(sn.Name.Value, new GloalObject() { Node = sn });
        //}

        internal void RegisterStruct(LexerNode lexer) {
            global.Add(lexer.Value, new GloalObject { Name = lexer });
        }

        public string IntelliSense(string variableName, string leters) {
            //var maybe = variables[variableName].Properties.All(x => x.StartsWith(leters, StringComparison.InvariantCultureIgnoreCase));
            return string.Empty;
        }


    }

    class SyntaxHighlighter {
        static Brush FromString(string color) {
            var converter = new System.Windows.Media.BrushConverter();
            return (Brush)converter.ConvertFromString(color);
        }

        static readonly Brush KeywordBrush = FromString("#569CD6");
        static readonly Brush NewKeywordsNameBrush = FromString("#4EC9B0");
        static readonly Brush SemanticNameBrush = FromString("#C8C8C8");
        static readonly Brush NumereticBrush = FromString("#B5CEA8");
        static readonly Brush StringBrush = FromString("#D69D85");
        static readonly Brush CommentsBrush = FromString("#57A64A");


        readonly FlowDocument document;
        readonly HashSet<string> keywords;
        readonly HashSet<string> systemFuncs = new HashSet<string> { "mul","register" };

        public SyntaxHighlighter(FlowDocument document, HashSet<string> keywords) {
            this.keywords = keywords;
            this.document = document;
        }

        public void Apply(TestAST.Node node) {
            switch (node) {
                case TestAST.CommentsNode comm:
                    ApplyForegroundValue(comm.Lex, Brushes.Green);
                    break;
                case TestAST.StructNode str:
                    Apply(str.DefinitionName);
                    Apply(str.TypeNode);
                    str.Children.ForEach(x => Apply(x));
                    break;
                case TestAST.CBufferNode cbuff:
                    Apply(cbuff.TypeNode);
                    Apply(cbuff.DefinitionName);
                    Apply(cbuff.Register);
                    cbuff.Children.ForEach(x => Apply(x));
                    break;
                case TestAST.FunctionDeclarationNode funcdec:
                    Apply(funcdec.TypeNode);
                    Apply(funcdec.DefinitionName);
                    if (funcdec.SemanticNameLex != null) {
                        ApplyForegroundValue(funcdec.SemanticNameLex, SemanticNameBrush);
                    }
                    funcdec.Children.ForEach(x => Apply(x));
                    funcdec.Vars.ForEach(x => Apply(x));
                    break;
                case TestAST.StructVariableDeclaration svd:
                    Apply(svd.TypeNode);
                    Apply(svd.DefinitionName);
                    ApplyForegroundValue(svd.SemanticNameLex, SemanticNameBrush);
                    break;
                case TestAST.DefinitionNode def:
                    if(def.VarNamesLex.Count == 1 && systemFuncs.Contains(def.VarNamesLex[0].Value)) {
                        ApplyForegroundValue(def.VarNamesLex[0],KeywordBrush);
                    }
                    foreach (var name in def.VarNamesLex) {
                       // ApplyForegroundValue(name, NewKeywordsNameBrush);
                    }
                    break;

                case TestAST.AssignmentVariableDeclaration assvd:
                    Apply(assvd.DefinitionName);
                    if(assvd.TypeNode != null) {
                        Apply(assvd.TypeNode);
                    }
                    Apply(assvd.Right);
                    break;
                case TestAST.FunctionCallNode funcall:
                    Apply(funcall.Name);
                    //funcall.Args.ForEach(x => Apply(x));
                    break;
                case TestAST.TypeNode dt:
                    ApplyForegroundValue(dt.TypeLex, keywords.Contains(dt.TypeLex.Value) ?  KeywordBrush : NewKeywordsNameBrush);
                    break;

                case TestAST.VariableDeclaration vardec:
                    Apply(vardec.TypeNode);
                    Apply(vardec.DefinitionName);
                    break;

                case TestAST.DefinitionObjectNode don:
                    don.Children.ForEach(x => Apply(x));
                    break;
            }
        }


        /// === ///


        public void Apply(FunctionNode sn) {
            switch (sn.Name.Token) {
                case ASTTokens.TypeIdentifier:
                    ApplyIdentifier((TypeIdentifierNode)sn.Name);
                    break;
            }
            //ApplyType();
            ApplyCollection(sn.Vars);
            ApplyCollection(sn.Body);
        }
        public void Apply(StructNode sn) {
            ApplyDeclaration(sn);
        }
        public void Apply(CbufferNode cbn) {
            ApplyDeclaration(cbn);
            //ApplyForegroundValue(cbn.Register.Func., Brushes.AliceBlue);
        }


        public void Apply(LexerNode lexer) {
            switch (lexer.Token) {
                case LexerTokens.Comment:
                    ApplyForegroundValue(lexer, Brushes.Green);
                    break;
            }
        }
        public void Apply(SyntaxException se) {
            ApplyForegroundValue(se.Lexer, Brushes.Red);
        }


        void ApplyDeclaration(DeclarationNode node) {
            ApplyIdentifier(node);
            ApplyCollection(node.Body);
        }
        void ApplyCollection(NodeCollection colle) {
            foreach (var pr in colle) {
                Apply(pr);
            }
        }
        void ApplyIdentifier(TypeIdentifierNode node) {
            ApplyType(node);
            if (keywords.Contains(node.Type.Value)) {
                ApplyForegroundValue(node.Type, KeywordBrush);
                ApplyForegroundValue(node.Name, Brushes.Turquoise);
            } else {
                ApplyForegroundValue(node.Type, Brushes.Turquoise);
            }

        }
        void ApplyType(TypeIdentifierNode node) {
            if (keywords.Contains(node.Type.Value)) {
                ApplyForegroundValue(node.Type, KeywordBrush);
            } else {
                ApplyForegroundValue(node.Type, Brushes.Turquoise);
            }

        }
        void Apply(Node pr) {
            switch (pr.Token) {
                case ASTTokens.TypeIdentifier:
                    ApplyType((TypeIdentifierNode)pr);
                    break;
                case ASTTokens.BinaryExpression:
                    var be = (OperatorNode)pr;
                    Apply(be.Left);
                    Apply(be.Right);
                    break;
                case ASTTokens.Assignment:
                    var assi = (AssignmentNode)pr;
                    Apply(assi.Left);
                    Apply(assi.Right);
                    break;
                case ASTTokens.FunctionCall:
                    var call = (FunctionCallNode)pr;
                    var name = (TypeIdentifierNode)call.Func;
                    if (systemFuncs.Contains(name.Name.Value)) {
                        ApplyForegroundValue(name.Name, KeywordBrush);
                    }
                    break;
            }
        }


        static void ApplyForegroundValue(LexerNode lexer, Brush brush) {
            var tp = lexer.TextPointer;
            var range = new TextRange(tp, tp.GetPositionAtOffset(lexer.Value.Length));
            range.ApplyPropertyValue(TextElement.ForegroundProperty, brush);
        }
    }
}
